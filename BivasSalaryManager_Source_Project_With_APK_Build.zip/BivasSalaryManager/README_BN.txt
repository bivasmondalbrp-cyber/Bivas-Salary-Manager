BIVAS SALARY MANAGER — Android Studio Source Project

এই ZIP-এ Android Studio-তে খোলার মতো Source Project এবং অফলাইন HTML অ্যাপ রয়েছে।

হিসাবের নিয়ম (আপনার Bivas_Salary_Sheet_Android_Compatible.xlsx অনুসারে):
- Monthly Basic Salary = ₹23,625
- Daily Basic = Monthly Basic / 25 = ₹945
- Hourly Rate = Daily Basic / 9 = ₹105
- Required Duty Hours = ঐ মাসের Normal working days × 9
- Sunday এবং Holiday-র দিন Normal working days/required hours-এ গণনা হয় না
- Normal দিনে সর্বোচ্চ 9 ঘণ্টা Regular; অতিরিক্ত সময় OT
- Sunday/Holiday-তে কাজের সম্পূর্ণ সময় OT
- Shortfall থেকে সর্বোচ্চ 2 দিন × 9 ঘণ্টা = 18 ঘণ্টা CL Adjust
- অবশিষ্ট Shortfall × ₹105 কাটা হবে
- 1st Payment = Basic - EPF - Mediclaim - Professional Tax - Shortfall Deduction
- 2nd Payment = OT Amount
- Total Salary = 1st Payment + 2nd Payment

APK তৈরি করতে:
1. Android Studio-তে এই project folder খুলুন।
2. Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
3. APK app/build/outputs/apk/debug/ এ তৈরি হবে।

নোট: এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখানে সরাসরি APK compile করা যায়নি। Source project-টি পরিবর্তনযোগ্য।

APK তৈরি করার জন্য (Cloud Build):
১) এই ZIP-টি GitHub-এ নতুন repository হিসেবে upload করতে হবে।
২) Repository-র Actions tab-এ গিয়ে “Build Android APK” workflow চালু করুন (প্রথম push-এও build হবে)।
৩) Build শেষ হলে Actions-এর run খুলে Artifacts থেকে BIVAS-SALARY-MANAGER-APK download করুন।
৪) ZIP খুলে app-debug.apk Android ফোনে install করুন। Android-এ “Install unknown apps” অনুমতি চাইতে পারে।

নোট: এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে সরাসরি APK compile করা যায়নি। Workflow যোগ করা হয়েছে যাতে GitHub-এর build server APK তৈরি করতে পারে।
